package tp;

import java.util.ArrayList;

public class Formation {
	
	// attributes
	private String identifiant ;
	public ArrayList<Matiere> list_Matiere = new ArrayList<Matiere>();
	
	// constructor
	public Formation(String idenrtifiant) {
		this.identifiant = identifiant ;
	}
	
	// getters
	public String getId() {
		return identifiant ;
	}
	public ArrayList<Matiere> getList_matiere(){
		return list_Matiere;
	}
	
	// ajouter un matiere
	public void ajouter_matiere(Matiere m) {
		if(!list_Matiere.contains(m))
			list_Matiere.add(m);
		else
			System.out.println("Cette matiere est deja dans la formation !");
	}
	
	// supprimer un matiere
	public void supprimer_matiere(Matiere m) {
			if(list_Matiere.contains(m))
				list_Matiere.remove(m);
			else
				System.out.println("Cette matiere n'est pas dans la formation !");
	}
	
	// connaitre coeff d'une matiere
	public int coeff_matiere(Matiere m) {
		if(list_Matiere.contains(m))
			return m.getCoeff();
		else {
			System.out.println("Cette matiere n'est pas dans la formation !");
			return -1;
		}
			
	}
		
}
