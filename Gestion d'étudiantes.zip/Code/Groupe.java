package tp;

import java.util.ArrayList;

public class Groupe {
	
	// attributes
	public ArrayList<Etudiant> list_Etudiant = new ArrayList<Etudiant>();
	
	// ajouter un etudiant
	public void ajouter_etudiant(Etudiant etud) {
		if(!list_Etudiant.contains(etud))
			list_Etudiant.add(etud);
		else
			System.out.println("Cette Etudiant est deja dans le groupe !");
	}
	
	//supprimer un etudiant
	public void supprimer_etudiant(Etudiant etud) {
		if(list_Etudiant.contains(etud))
			list_Etudiant.remove(etud);
		else
			System.out.println("Cette matiere n'est pas dans la formation !");
	}
	
	// moyene de groupe dans une matiere
	public float moyene_matiere(Matiere m) {
		float moy = 0.0f ;
		for(Etudiant e : list_Etudiant) {
			moy += e.calcule_moyene(m);
		}
		return moy/list_Etudiant.size();
	}
	
	// moyene general de group
	
	public float moyene_general() {
		float moy_gen=0.0f;
		for(Etudiant e : list_Etudiant) {
			moy_gen += e.moy_general();
		}
		System.out.println("La moyene general de groupe est : "+moy_gen);
		return moy_gen/list_Etudiant.size();
	}
	
	// triParMerite
	public ArrayList<Etudiant> triParMerite(){
		if(list_Etudiant.isEmpty()) {
			return null ;
		}
		else {
			ArrayList<Etudiant> list_trie = new ArrayList<Etudiant>();
			Etudiant etud_max  ;
			while(!list_Etudiant.isEmpty()) {
				
				etud_max  = list_Etudiant.get(0);
				int pos =0;
				for(int i =1;i<list_Etudiant.size()-1;i++) {
					if(list_Etudiant.get(i).moy_general()>etud_max.moy_general()) {
						etud_max = list_Etudiant.get(i);
						pos=i;
					}
				}
				list_trie.add(list_Etudiant.get(pos));
				list_Etudiant.remove(pos);
			}
			return list_trie;
		}
		
	}
	
	// trieParMatiere
	public ArrayList<Etudiant> triParMerite(Matiere m){
		if(list_Etudiant.isEmpty()) {
			return null ;
		}
		else {
			ArrayList<Etudiant> list_trie = new ArrayList<Etudiant>();
			Etudiant etud_min  ;
			while(!list_Etudiant.isEmpty()) {
				
				etud_min  = list_Etudiant.get(0);
				int pos =0;
				for(int i =1;i<list_Etudiant.size()-1;i++) {
					if(list_Etudiant.get(i).calcule_moyene(m)<etud_min.calcule_moyene(m)) {
						etud_min = list_Etudiant.get(i);
						pos=i;
					}
				}
				list_trie.add(list_Etudiant.get(pos));
				list_Etudiant.remove(pos);
			}
			return list_trie;
		}
	}
	
	// triParAlpha
	public ArrayList<Etudiant> triParAlpha(){
		if(list_Etudiant.isEmpty()) {
			return null ;
		}
		else {
			ArrayList<Etudiant> list_trie = new ArrayList<Etudiant>();
			Etudiant etud_min  ;
			while(!list_Etudiant.isEmpty()) {
				
				etud_min  = list_Etudiant.get(0);
				int pos =0;
				for(int i =1;i<list_Etudiant.size()-1;i++) {
					if(list_Etudiant.get(i).getId().getNom().compareTo(etud_min.getId().getNom())<0) {
						etud_min = list_Etudiant.get(i);
						pos=i;
					}
				}
				list_trie.add(list_Etudiant.get(pos));
				list_Etudiant.remove(pos);
			}
			return list_trie;
		}
	}
}
