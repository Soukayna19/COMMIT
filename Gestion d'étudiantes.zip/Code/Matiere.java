package tp;

public class Matiere {
	
	// attributes
	private String nom ;
	private int coeff ;
	private float note1=0.0f, note2=0.0f, note3=0.0f ;
	
	// constructor
	public Matiere(String nom , int coeff) {
		this.nom = nom;
		this.coeff = coeff;
	}
	
	// getters
	public String getNom() {
		return nom ;
	}
	public int getCoeff() {
		return coeff;
	}
	
	public float getNote1() {
		return note1;
	}

	public float getNote2() {
		return note2;
	}

	public float getNote3() {
		return note3;
	}

	// setters
	public void setNote1(float note1) {
		this.note1 = note1;
	}
	public void setNote2(float note2) {
		this.note2 = note2;
	}
	public void setNote3(float note3) {
		this.note3 = note3;
	}
	
	
}
