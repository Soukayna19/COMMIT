package tp;

import java.util.ArrayList;

public class Etudiant {
	
	// attributes
	private Identite id ;
	private Formation formation ;
	private ArrayList<Float> resultat = new ArrayList<>();
	
	//constructor
	public Etudiant(Identite id , Formation formation) {
		this.id = id ;
		this.formation = formation;
	}
	
	// ajouter une note 
	public void ajouter_note(Matiere m , float note1 , float note2, float note3) {
		if(formation.list_Matiere.contains(m)) {
			m.setNote1(note1);
			m.setNote2(note2);
			m.setNote3(note3);
		}
		else {
			System.out.println("Cette matiere n'est pas dans la formation !");
		}
	}
	
	// calculer moyene d'etudiant dans une matiere
	public float calcule_moyene(Matiere m) {
		if(formation.list_Matiere.contains(m)) {
			float moy = (m.getNote1()+m.getNote2()+m.getNote3())/3;
			return moy;
		}
		else {
			System.out.println("Cette matiere n'est pas dans la formation !");
			return -1;
		}
	}
	
	//modifier formation
	public void modifier_formation(Formation f) {
		formation =f ;
	}
	
	// moyene general
	public float moy_general() {
		int somme_coeff = 0 ;
		float some_note =0.0f;
		for(Matiere m : formation.list_Matiere) {
			somme_coeff +=m.getCoeff();
			some_note += calcule_moyene(m) * m.getCoeff();
		}
		float moy_general = some_note/somme_coeff;
		return moy_general;

	}
	
	// getid
	public Identite getId() {
		return id;
	}
}
